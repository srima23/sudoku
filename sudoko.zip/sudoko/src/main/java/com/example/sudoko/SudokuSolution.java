package com.example.sudoko;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

	@Entity
	public class SudokuSolution {
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	    // Grid representation as a 2D array
	    @Column(length = 81)
	    private String grid;

	    // Getters and setters
	}



