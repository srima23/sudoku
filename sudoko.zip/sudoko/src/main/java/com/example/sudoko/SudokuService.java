package com.example.sudoko;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.sudoko.entity.User;
import com.example.sudoko.repository.SudokuPuzzleRepository;
@Service


public class SudokuService {
	private final SudokuPuzzleRepository puzzleRepository;
@Autowired
    public SudokuService(SudokuPuzzleRepository puzzleRepository) {
	  this.puzzleRepository=puzzleRepository;
	  
}


	public SudokuPuzzle generatePuzzle(User creator) {
      SudokuPuzzle puzzle=new SudokuPuzzle();
      puzzle.setGrid("000000000000000000000000000000000000000000000000000000000000000000000000000000000");
      puzzle.setCreator(creator);
      return puzzle;

	}

public Long savePuzzle(String grid) {
	SudokuPuzzle puzzle=new SudokuPuzzle();
	puzzle.setGrid(grid);
	SudokuPuzzle savedpuzzle=puzzleRepository.save(puzzle);
	
	return savedpuzzle.getId();
}

public boolean verifyPuzzle(SudokuPuzzle puzzle) {
    return puzzle.isValid() && puzzle.isComplete();
}
public SudokuPuzzle getPuzzleById(Long id) {
    return puzzleRepository.findById(id).orElse(null);
}
public List<SudokuPuzzle> getAllPuzzles() {
    return puzzleRepository.findAll();
}

		
//private int[][] convertStringToGrid(String gridString) {
//	int [][] puzzleGrid = new int[9][9];
//	int index=0;
//	
//	
//	for(int sudrow=0;sudrow<9;sudrow++) {
//		for(int sudcol=0;sudcol<9;sudcol++) {
//			char cellChar= gridString.charAt(index);
//			puzzleGrid[sudrow][sudcol]= Character.getNumericValue(cellChar);
//			index++;
//		}
//	}
//
//	return puzzleGrid;
//}
//	
   
private boolean isValidSudokuSolution(int[][] puzzleGrid) {
			// TODO Auto-generated method stub
	return false;
}


}
