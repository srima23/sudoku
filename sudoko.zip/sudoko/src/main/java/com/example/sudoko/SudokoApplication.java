package com.example.sudoko;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SudokoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SudokoApplication.class, args);
	}

}
