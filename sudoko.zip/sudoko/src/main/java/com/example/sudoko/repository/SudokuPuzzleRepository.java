package com.example.sudoko.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.sudoko.SudokuPuzzle;

	
@Repository
public interface SudokuPuzzleRepository extends JpaRepository<SudokuPuzzle, Long> {
}



