package com.example.sudoko;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.example.sudoko.entity.User;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class SudokuPuzzle {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    public Long getId() {
    	// TODO Auto-generated method stub
    	return getId();}


    // Grid representation as a 2D array
    @Column(length = 81)
    private String grid;
    
    public String getGrid() {
		return getGrid();
	}
	public void setGrid(String grid) {
		this.grid = grid;
	}
	
    
@ManyToOne
@JoinColumn(name="creater_id",nullable=false)
private User creater;
    
 public void setGridValue(int sudrow,int sudcol,int value) {
	 
	 if(sudrow<0||sudrow>=9||sudcol<0||sudcol>=9) {
		 throw new IllegalArgumentException("Invalid row or column index");
	 }
	 int index=sudrow*9+sudcol;
	 
	 if(value<0||value>9) {
		 throw new IllegalArgumentException("Invalid value");
	 }
	 StringBuilder updateGrid=new StringBuilder(grid);
	 updateGrid.setCharAt(index, Character.forDigit(value,10));
	 grid=updateGrid.toString();
 }
 
 
public boolean isValid() {
	
	return isValidRows() && isValidColumns() && isValidSubgrid();
	
}

private boolean isValidRows() {
  for(int sudrow=0;sudrow<9;sudrow++)
  {
	  if(!isValidSet(getRowValues(sudrow))) {
		  return false;
	  }
	  
  }
	return true;
}

private boolean isValidColumns() {
	  for(int sudcol=0;sudcol<9;sudcol++)
	  {
		  if(!isValidSet(getColumnValues(sudcol))) {
			  return false;
		  }
		  
	  }
		return true;
	}
private boolean isValidSubgrid() {
	for(int startrow=0;startrow<9;startrow++) {
		for(int startcol=0;startcol<9;startcol++) {
			if(!isValidSet(getSubgridValues(startrow,startcol))) {
				return false;
			}	
		}
	}
	
	return true;
}

private List<Integer> getRowValues(int sudrow) {
    List<Integer> values = new ArrayList<>();
    for (int sudcol = 0; sudcol < 9; sudcol++) {
        values.add(getCellValue(sudrow, sudcol));
    }
	
	return values;
}


private List<Integer> getColumnValues(int sudcol) {
    List<Integer> values = new ArrayList<>();
    for (int sudrow = 0; sudrow < 9; sudrow++) {
        values.add(getCellValue(sudrow, sudcol));
    }
    return values;
}
private List<Integer> getSubgridValues(int startrow, int startcol) {
	 List<Integer> values = new ArrayList<>();
     for (int row = startrow; row < startrow + 3; row++) {
         for (int col = startcol; col < startcol + 3; col++) {
             values.add(getCellValue(row, col));
         }
     }
     return values;
 }


private boolean isValidSet(List<Integer> values) {
	Set<Integer> uniValues= new HashSet<>();
	for(int value:values) {
		if(value!=0 && !uniValues.add(value)) {
			return false; // duplicate value
		}
	}
	
	return true;
}


private Integer getCellValue(int sudrow, int sudcol) {
	int index=sudrow*9+sudcol;
	char cellChar=grid.charAt(index);
	return Character.getNumericValue(cellChar);
}


 boolean isComplete() {
	for (int sudrow = 0; sudrow < 9; sudrow++) {
		for (int sudcol = 0; sudcol < 9; sudcol++) {
			if(getCellValue(sudrow,sudcol)==0) {
				return false;
			}
		}
	}
	return true;
 }

public void setCreator(User creator) {
	// TODO Auto-generated method stub
	
}}

	


