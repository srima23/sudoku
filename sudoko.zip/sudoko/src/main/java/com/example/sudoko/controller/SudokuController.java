package com.example.sudoko.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.sudoko.SudokuPuzzle;
import com.example.sudoko.SudokuService;

@RestController
@RequestMapping("/api/sudoku")
public class SudokuController {
    @Autowired
    private SudokuService sudokuService;

    @PostMapping("/create")
public ResponseEntity<SudokuPuzzle> createSudokuPuzzle() {
    SudokuPuzzle puzzle = sudokuService.generatePuzzle(null);
    return ResponseEntity.ok(puzzle);
}

@PostMapping("/save")
public ResponseEntity<Long> saveSudokuPuzzle(@RequestParam("grid") String grid) {
    Long puzzleId = sudokuService.savePuzzle(grid);
    return ResponseEntity.ok(puzzleId);
}


@PostMapping("/verify")
public ResponseEntity<Boolean> verifySudokuSolution(@RequestParam("grid") String grid) {
    boolean isCorrect = sudokuService.verifyPuzzle(grid);
    return ResponseEntity.ok(isCorrect);
}
}


