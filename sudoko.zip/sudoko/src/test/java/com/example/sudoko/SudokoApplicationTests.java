package com.example.sudoko;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SudokoApplicationTests {

	@Test
	void contextLoads() {
	}

}
